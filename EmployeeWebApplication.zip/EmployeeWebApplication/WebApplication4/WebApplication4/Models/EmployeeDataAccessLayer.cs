﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication4.Models
{
    public class EmployeeDataAccessLayer : Controller
    {
        string connectionString = @"Data Source=.;Initial Catalog=EmployeeDatabase;Integrated Security=True";
       
        //To View all employees details    
        public IEnumerable<Employee> GetAllEmployees()
        {
            List<Employee> lstemployee = new List<Employee>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spGetAllEmployees", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Employee employee = new Employee();

                    employee.EmployeeID = Convert.ToInt32(rdr["EmployeeID"]);
                    employee.EmployeeNumber = Convert.ToInt32(rdr["EmployeeNumber"]);
                    employee.FirstName = Convert.ToString(rdr["FirstName"]);
                    employee.LastName = Convert.ToString(rdr["LastName"]);
                    employee.HireDate = Convert.ToDateTime(rdr["HireDate"]);

                    employee.PhoneType = Convert.ToString(rdr["PhoneType"]);
                    employee.PhoneNumber = Convert.ToString(rdr["PhoneNumber"]);
                    employee.Address1 = Convert.ToString(rdr["Address1"]);
                    employee.Address2 = Convert.ToString(rdr["Address2"]);
                    employee.City = Convert.ToString(rdr["City"]);

                    employee.State = Convert.ToString(rdr["State"]);
                    employee.ZipCode = Convert.ToInt32(rdr["ZipCode"]);
                   


                    lstemployee.Add(employee);
                }
                con.Close();
            }
            return lstemployee;
        }

       
        //Get the details of a particular employee  
        public Employee GetEmployeeData(int? id)
        {
            Employee employee = new Employee();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM Employees WHERE EmployeeID= " + id;
                SqlCommand cmd = new SqlCommand(sqlQuery, con);

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    employee.EmployeeID = Convert.ToInt32(rdr["EmployeeID"]);
                    employee.EmployeeNumber = Convert.ToInt32(rdr["EmployeeNumber"]);
                    employee.FirstName = Convert.ToString(rdr["FirstName"]);
                    employee.LastName = Convert.ToString(rdr["LastName"]);
                    employee.HireDate = Convert.ToDateTime(rdr["HireDate"]);
                }
            }
            return employee;
        }

       
    }
} 
   